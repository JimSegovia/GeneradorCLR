import re

def procesar_gramatica(entrada, codigos_terminales):
    if codigos_terminales is None:
        raise ValueError("❌ Debes proporcionar un diccionario con los códigos de los terminales.")

    producciones = []
    no_terminales = set()
    terminales = set()

    # Unir líneas que continúan
    lineas = []
    buffer = ""
    for linea in entrada.strip().split('\n'):
        linea = linea.strip()
        if not linea:
            continue
        if '→' in linea or '->' in linea:
            if buffer:
                lineas.append(buffer)
            buffer = linea
        else:
            buffer += ' ' + linea
    if buffer:
        lineas.append(buffer)

    # Procesar producciones
    for linea in lineas:
        if '→' in linea:
            izquierda, derecha = map(str.strip, linea.split('→'))
        else:
            izquierda, derecha = map(str.strip, linea.split('->'))

        no_terminales.add(izquierda)

        alternativas = [alt.strip() for alt in derecha.split('|')]
        for alt in alternativas:
            alt = alt.strip()
            if alt == 'λ':
                simbolos = []  # Producción vacía
            else:
                simbolos = re.findall(r'<[^<>]+>|[^<>\s]+', alt)

            producciones.append((izquierda, simbolos))
            for simbolo in simbolos:
                if re.match(r'<[^<>]+>', simbolo):
                    no_terminales.add(simbolo)
                else:
                    terminales.add(simbolo)

    # Validar códigos de terminales
    faltantes = [t for t in terminales if t not in codigos_terminales]
    if faltantes:
        raise ValueError(f"❌ Faltan códigos para los terminales: {', '.join(faltantes)}")

    # Mostrar no terminales
    print("No terminales:")
    print('|'.join(sorted(no_terminales)))

    # Mostrar terminales con códigos
    #("\nTerminales con códigos:")
    #for t in sorted(terminales):
    #print(f"{t} = {codigos_terminales[t]}")

    # Mostrar terminales codificados en formato '|'
    print("\nTerminales (formato codigo para copiar):")
    print('|'.join(str(codigos_terminales[t]) for t in sorted(terminales)))

    # Mostrar terminales en formato '|'
    print("\nTerminales:")
    print('|'.join(sorted(terminales)))

    # Mostrar producciones sin espacios alrededor de →
    print("\nProducciones (con terminales codificados):")
    for izquierda, simbolos in producciones:
        reemplazada = []
        for s in simbolos:
            if s in codigos_terminales:
                reemplazada.append(str(codigos_terminales[s]))
            else:
                reemplazada.append(s)
        print(f"{izquierda}→{' '.join(reemplazada)}")

# === USO ===

entrada = """
<S>→ initHabit { <Declaraciones> mainZoo { <Instrucciones> } } finHabit

<Declaraciones> → <DelVariable> <Declaraciones> | 
<Clase> <Declaraciones> | 
<Funciones globales> <Declaraciones> | λ

<DelVariable> → <TipoPrimitivo> <DeclSimple> 
| TORT <TipoPrimitivo> <DeclInicializada> 
| <TipoClase> <DeclObj> 
| <AsignacionObj>
	| <AsignacionArreglo>
| <AsignacionElemArr>
<DeclSimple>→  <ListaIds> ; | 
<DeclInicializada>  | 
<Arreglos> ;

<DeclInicializada> →  <Inicializar> ;  
                  		 | <InicializarArreglos> ; 

<DeclObj> → <ObjSimple> | <ObjArreglo> 

<ObjSimple>  → id <IniObjOpcional> ; 
<IniObjOpcional>   → = NUEVO <TipoClase> ( <Argumentos> )  |  λ

<ObjArreglo> → [ ] id <IniObjArregloOpcional> ;  
<IniObjArregloOpcional> → = NUEVO <TipoClase> [ <DimenPosicion> ]  | λ

<AsignacionObj>  → id = NUEVO <TipoClase> ( <Argumentos> ) ;  
<AsignacionArreglo>→ id = NUEVO <TipoClase> [ <DimenPosicion> ] ; 
<AsignacionElemArr>→ id [ <DimenPosicion> ] = NUEVO <TipoClase> ( <Argumentos> ) ;
	<ObjDirectoParametro>→ NUEVO <TipoClase> ( <Argumentos> )

<ListaIds> → id <ListaIdsCont>
<ListaIdsCont> → , <ListaIds> | λ
<Inicializar> → id = <valor>  <MasDeclInicializadas>
<MasDeclInicializadas> → , <Inicializar> | λ

<Arreglos> → id [ <DimenPosicion> ] <MasArreglos>
<MasArreglos> → , <Arreglos> | λ
<InicializarArreglos> → id [ ] => { <ListaValores> } <MasIniArreglos>
<MasIniArreglos> → , <InicializarArreglos> |  λ

<ListaValores> → <ListaIds> | <ListaString> | <ListaNum> | <ListaBool> | <ListaChar>
<ListaString>→ lit_str  <MasString>
	<MasString>→ , <ListaString>  |  λ
<ListaNum>→ <Num> <MasNum>
	<MasNum>→ , <ListaNum>  |  λ
	<ListaBool>→ <ExpreBooleanos> <MasBool>
<ExpreBooleanos> → <Booleanos> | <ExpreLogica>
<MasBool>→ , <ListaBool>  |  λ
	<ListaChar>→ lit_char <MasChar>
	<MasChar>→ , <ListaChar>  |  λ
<ListaExpreArit>→ <ExpreArit> <MasExpreArit>
	<MasExpreArit>→ , <ListaExpreArit>  |  λ

<Argumentos>→ <valor> <MasArgumentos> |  λ
<MasArgumentos>→ , <Argumentos> |  λ

<DimenPosicion> → id | lit_ent
 <Valor> → <ExpreCompletas> | <Num> | <Booleanos> | lit_str | lit_char |  id <ConArrayElem> 
<Num>→ lit_ent | lit_decimal
<Booleanos> → verdad | falso                                        
<TipoClase> → id
<TipoPrimitivo> → ent | ant | boul | stloro | char 
	<ConArrayElem> → [ <DimenPosicion> ] |  λ

<Clase> → classHabit  <TipoClase> { <Miembros> } ;
<Miembros> → <Atributo> <Miembros> 
| <Metodo> <Miembros> 
| <Constructor> <Miembros> 
|  λ

<Constructor> → INICIAR <TipoClase> ( <Parametros> ) { <Instrucciones> }

<Atributo> → <Acceso>  <DelVariable> <Atributo>

<Acceso> → libre | encerrado | protect | λ 

<Metodo> → <Acceso> <Met> 
<Met> → <MetodoConRetorno> | <MetodoSinRetorno>
<MetodoConRetorno> → <TipoPrimitivo> <MetPrefijo> id ( <Parametros> )  { <Instrucciones>  devolver  <Valor> ; }
<MetodoSinRetorno> →  corpse <MetPrefijo> id ( <Parametros> ) {<Instrucciones> }
 
<MetPrefijo> → met-> | acced-> | modif-> | λ

<FuncionesGlobales> → compor <Func>
<Func> → <FuncConRetorno> | <FuncCorpse>
<FuncConRetorno> → <TipoPrimitivo> id ( <Parametros> ) { <Instrucciones> devolver <Valor> ; }
<FuncCorpse> → corpse id ( <Parametros> ) { <Instrucciones> }

<Parametros> → <VeriParametros>  |  λ 
<VeriParametros> → <TiposDeParametros> <ContParametros>
<ContParametros> → , <VeriParametros> | λ 
<TiposDeParametros> →<TipoPrimitivo> id <ConArray> 
| <TipoClase> <ConArray>  id
| <ObjDirectoParametro>
<ConArray> → [ ] |   λ

<Instrucciones> → <Instruccion> <Instrucciones> | λ
<Instruccion> → <DeclVariable> | <Llamadas>| <Paso> | <Asignacion> | <ControlFlujo> | <Rugg> | <Reci> | <OpHuir>

<Asignacion> → <Variable> = <Valor>  
<Variable> → id | self .. id | id [ <ExprAritmeticas> ]
<Paso> → id <MasMasMenosMenos> ;
<MasMasMenosMenos> → ++ | --


<Rugg> → rugg ( <ExpreParaRugg> ) ;
<Reci> → reci (  <ExpreReci> ) ;
<ExpreReci> → id <ConArray>
<ExpreParaRugg> → <valor> <MasExpreParaRugg> ;
<MasExpreParaRugg> → <<  <ExpreParaRugg>  | λ

<ExpreCompletas> → <Expre> | <Llamadas>
<Expre> → <ExprLogica> | <ExprAritmeticas>

<ExprAritmeticas> → <Termino> <ExprAritmeticas’>
<ExprAritmeticas’> → <OpeSumaResta> <Termino> <ExprAritmeticas’> | λ
<Termino>  → <Factor> <Termino’>
<Termino’> → <OpeMulDiv> <Factor> <Termino’> | λ
<Factor>   → ( <ExprAritmeticas> ) | <Var>
<OpeSumaResta> → + | –
<OpeMulDiv>    → * | /

<ExprLogica> → <Condicion> <ExprLogica’>
<ExprLogica’> → <OpeLogico> <Condicion> <ExprLogica’> | λ
<Condicion>  → <Negacion> <UnidadCondicional>
<Negacion> → ! | λ
<UnidadCondicional>  → ( <ExprLogica> )
                     | <Comparacion>
                     | <ValorSimple>      
<Comparacion>  → <Var1> <OpeRelacionalNum> <Var1>
                     | <Var1> <OpeIgualdad> <Var1>
<ValorSimple>→ id | <Booleano>  
<Var> → <Num> | id 
<Var1> → <Var> | <ExprAritmeticas>
<Var2> → <Var1> | lit_str | lit_char | <Booleanos>
<OpeRelacionalNum> →  > | < | >= | <= 
<OpeIgualdad> → == | !=
<OpeLogico>  →  Y¡ | O¡

<Llamadas> → id <FuncOMet>;
<FuncOMet> →  ( <Argumentos>) | . id ( <Argumentos>) 

<ControlFlujo> → <IfElse> |<While> | <DoWhile> | <For> | <Switch> | 
<IfElse> →cama ( <Expre> ) { <Instrucciones> } leon <IfElseAnidadas>
<IfElseAnidadas> → <IfElse> | { <Instrucciones> }
<While> → merodear ( <Expre> ) { <Instrucciones> }
<DoWhile> → me { <Instrucciones> } merodear ( <Expre> ) ;
<For>→ rondar ( <DeclOAsignacion> ; <ExprLogica> ; <IncreDecre> ) { <Instrucciones> }
<Switch> → instinto ( <Expre> ) { <ListaReaccion> <OpInstintoFinal> }
<ListaReaccion> → reaccion <definicion> : { <Instrucciones> } <OpHuir> <ListaReaccion> 			| λ
<definicion> →lit_ent | lit_char
<OpHuir> →huir ; | λ
<OpInstintoFinal> →instintoFinal : { <Instrucciones> } | λ

<DeclOAsignacion> → <TipoPrimitivo> <Inicializar> 
<IncreDecre> →  id <ExpreOIncreDecre> <MasIncreDecre> 
<ExpreOIncreDecre> → = <ExprAritmetica> | <MasMasMenosMenos> 
<MasIncreDecre>  → <IncreDecre>  | λ

"""

codigos_terminales = {
'initHabit': 400,
'mainZoo': 401,
'finHabit': 402,
'classHabit': 403,
'acced->': 404,
'modif->': 405,
'met->': 406,
'libre': 407,
'encerrado': 408,
'protect': 409,
'compor': 410,
'ent': 411,
'ant': 412,
'boul': 413,
'corpse': 414,
'stloro': 415,
'char': 416,
'self': 417,
'NUEVO': 418,
'INICIAR': 419,
'TORT': 420,
'devolver': 421,
'rugg': 422,
'reci': 423,
'cama': 424,
'leon': 425,
'merodear': 426,
'rondar': 427,
'me': 428,
'instinto': 429,
'instintoFinal': 430,
'reaccion': 431,
'huir': 432,
'verdad': 433,
'falso': 434,
'==': 435,
'!=': 436,
'<': 437,
'<=': 438,
'>': 439,
'>=': 440,
'Y¡': 441,
'O¡': 442,
'!': 443,
'+': 444,
'-': 445,
'*': 446,
'/': 447,
'++': 448,
'--': 449,
'(': 450,
')': 451,
'{': 452,
'}': 453,
'[': 454,
']': 455,
';': 456,
':': 457,
',': 458,
'.': 459,
'..': 460,
'<<': 461,
'id': 500,
'lit_str': 501,
'lit_char': 502,
'lit_ent': 503,
'lit_decimal': 504,
'comentario': 505,
'=': 506,
'=>': 507,
'ERROR': 911,
'EOF': 999,
}

procesar_gramatica(entrada, codigos_terminales)
